angular.module('app.services', [])

.factory('BlankFactory', [function(){

}])

.service('BlankService', [function(){

}])

  .factory('activityDefault', ['$http', function ($http) {
    var data;
    return {
      getData: function (callback) {
        if(data) {
          callback(data);
        } else {
          $http.get('http://10.42.0.1/fitbit_api/api/web/activity').success(function(d) {
            callback(data = d);
          });
        }
      }
    };
  }])

.factory('sleepDefault', ['$http', function ($http) {
  var data;
  return {
    getData: function (callback) {
      if(data) {
        callback(data);
      } else {
        $http.get('http://10.42.0.1/fitbit_api/api/web/sleep').success(function(d) {
          callback(data = d);
        });
      }
    }
  };
}])

.factory('profileDefault', ['$http', function ($http) {
  var data;
  return {
    getData: function (callback) {
      if(data) {
        callback(data);
      } else {
        $http.get('http://10.42.0.1/fitbit_api/api/web/profile').success(function(d) {
          callback(data = d);
        });
      }
    }
  };
}])

  .factory('performanceDefault', ['$http', function ($http) {
    var data;
    return {
      getData: function (callback) {
        if(data) {
          callback(data);
        } else {
          $http.get('http://10.42.0.1/fitbit_api/api/web/performance').success(function(d) {
            callback(data = d);
          });
        }
      }
    };
  }]);
